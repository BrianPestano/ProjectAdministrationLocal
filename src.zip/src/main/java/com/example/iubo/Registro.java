package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class Registro {

    @FXML
    private TextField nombreField;

    @FXML
    private TextField apellidoField;

    @FXML
    private TextField dniField;

    @FXML
    private TextField correoField;

    @FXML
    private TextField paisField;

    @FXML
    private TextField fechaNacimientoField;

    @FXML
    private TextField institucionOrigenField;

    @FXML
    private TextField fechaAltaField;

    @FXML
    private TextField fechaBajaField;

    @FXML
    private ComboBox<String> doctorComboBox;

    @FXML
    private TextField grupoField;

    @FXML
    private ComboBox<String> motivoComboBox;

    public void registrar(ActionEvent event) {
        // Obtener los datos ingresados por el usuario
        String nombre = nombreField.getText();
        String apellido = apellidoField.getText();
        String dni = dniField.getText();
        String correo = correoField.getText();
        String pais = paisField.getText();
        String fechaNacimiento = fechaNacimientoField.getText(); // Cambiado a String
        String institucionOrigen = institucionOrigenField.getText();
        String fechaAlta = fechaAltaField.getText(); // Cambiado a String
        String fechaBaja = fechaBajaField.getText(); // Cambiado a String
        String doctor = doctorComboBox.getValue();
        String grupo = grupoField.getText();
        String motivo = motivoComboBox.getValue();

        // Guardar los datos en la base de datos
        boolean registroExitoso = guardarDatosPersonales(dni, nombre, apellido, correo, pais, fechaNacimiento,
                institucionOrigen, fechaAlta, fechaBaja, doctor, grupo, motivo);

        if (registroExitoso) {
            // Mostrar un mensaje de éxito si el registro fue exitoso
            mostrarMensaje("Registro exitoso");
        } else {
            // Mostrar un mensaje de error si hubo un problema al registrar los datos
            mostrarMensaje("Error al registrar los datos");
        }
    }

    private boolean guardarDatosPersonales(String dni, String nombre, String apellido, String correo,
                                           String pais, String fechaNacimiento, String institucionOrigen,
                                           String fechaAlta, String fechaBaja, String doctor,
                                           String grupo, String motivo) {
        // Conectar a la base de datos
        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la sentencia SQL para insertar los datos en la tabla DatosPersonales
            String sql = "INSERT INTO DatosPersonales (DNI, nombre, apellidos, Gmail, Pais, fecha_nacimiento, " +
                    "institucion_origen, fecha_alta, fecha_baja, doctor, grupo, motivo) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, dni);
            statement.setString(2, nombre);
            statement.setString(3, apellido);
            statement.setString(4, correo);
            statement.setString(5, pais);
            statement.setString(6, fechaNacimiento); // Cambiado a String
            statement.setString(7, institucionOrigen);
            statement.setString(8, fechaAlta); // Cambiado a String
            statement.setString(9, fechaBaja); // Cambiado a String
            statement.setString(10, doctor);
            statement.setString(11, grupo);
            statement.setString(12, motivo);

            // Ejecutar la sentencia SQL para insertar los datos
            int filasAfectadas = statement.executeUpdate();

            // Confirmar la transacción
            connection.commit();

            // Devolver true si se insertaron correctamente todas las filas
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje);
    }
}
