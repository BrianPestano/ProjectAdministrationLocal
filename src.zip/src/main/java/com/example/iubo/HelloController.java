package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import javax.swing.JOptionPane;

public class HelloController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Label errorLabel;

    public void entrar(ActionEvent event) {
        String username = usernameField.getText();
        String password = passwordField.getText();

        // Aquí iría la lógica para verificar las credenciales del usuario
        if (username.equals("admin") && password.equals("nimda")) {
            // Si las credenciales son correctas, cargar la vista de registro
            cargarVistaRegistro(event);
        } else {
            // Si las credenciales son incorrectas, mostrar un mensaje de error
            mostrarMensajeError("Credenciales incorrectas");
        }
    }

    private void cargarVistaRegistro(ActionEvent event) {
        try {
            // Cargar el FXML de Registro.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Principal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene scene = new Scene(root);

            // Obtener el escenario actual
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(scene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace(); // Manejo básico de errores, reemplázalo con manejo de errores adecuado en tu aplicación
        }
    }

    private void mostrarMensajeError(String mensaje) {
        JOptionPane.showMessageDialog(null, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
