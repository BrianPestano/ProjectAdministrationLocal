package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;
import javafx.fxml.FXML;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdmGrupo {
        @FXML
        private TextField nombregrupo_crear;
        @FXML
        private TextField denominacion;

        @FXML
        private TextField nombrejefe_crear;

        @FXML
        private TextField apellidosjefe_crear;

        @FXML
        private TextField fecha_crear;

        @FXML
        private TextArea vergrupos_bucar;

        @FXML
        private TextArea verpesonas_buscar;

        @FXML
        private TextField nombre_bucar;

        @FXML
        private TextField nombre_borar;

    public void creargrupo(ActionEvent event) {
        // Obtener los datos del formulario
        String nombreGrupo = denominacion.getText();
        String nombreDenominacion = nombregrupo_crear.getText();
        String nombreJefe = nombrejefe_crear.getText();
        String apellidosJefe = apellidosjefe_crear.getText();
        String fechaCreacion = fecha_crear.getText();
        if (campoVacio(nombreGrupo, nombreDenominacion, nombreJefe, apellidosJefe,fechaCreacion)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarCampos(nombreGrupo, nombreDenominacion,nombreJefe, apellidosJefe)) {
            mostrarAlerta("Error", "Los campos deben contener solo letras y tildes.");
            return;
        }

        // Validar el formato de la fecha
        if (!validarFormatoFecha(fechaCreacion)) {
            mostrarAlerta("Error", "El formato de la fecha debe ser dd/dd/dddd.");
            return;
        }
        // Aquí iría la lógica para insertar los datos en la base de datos o realizar otras operaciones

        // Simulando la inserción en la base de datos
        boolean insercionExitosa = insertarGrupoEnBaseDeDatos(nombreGrupo, nombreDenominacion,nombreJefe, apellidosJefe, fechaCreacion);

        // Verificar si la inserción fue exitosa
        if (insercionExitosa) {
            // Mostrar mensaje de éxito
            mostrarAlerta("Éxito", "Grupo creado exitosamente.");

        } else {
            // Mostrar mensaje de error
            mostrarAlerta("Error", "Hubo un problema al crear el grupo.");
        }
    }
    private boolean campoVacio(String... campos) {
        for (String campo : campos) {
            if (campo == null || campo.trim().isEmpty()) {
                return true; // Si encuentra un campo vacío, devuelve true
            }
        }
        return false; // Si ninguno de los campos está vacío, devuelve false
    }
    private boolean validarCampos(String... campos) {
        String regex = "^[a-zA-ZáéíóúüÁÉÍÓÚÜ\\s]+$";
        for (String campo : campos) {
            if (!campo.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarFormatoFecha(String fecha) {
        String regex = "^\\d{2}/\\d{2}/\\d{4}$";
        return fecha.matches(regex);
    }

    // Método para mostrar una alerta
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private boolean insertarGrupoEnBaseDeDatos(String nombreGrupo, String nombreDenominacion, String nombreJefe, String apellidosJefe, String fechaCreacion) {
        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la sentencia SQL para insertar los datos en la tabla Grupo
            String sql = "INSERT INTO Grupo (NombreGrupo, nombreDenominacion, nombreJefe, ApellidoJefe, fechaCreacion) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nombreGrupo);
            statement.setString(2, nombreDenominacion);
            statement.setString(3, nombreJefe);
            statement.setString(4, apellidosJefe);
            statement.setString(5, fechaCreacion);

            // Ejecutar la sentencia SQL para insertar los datos
            int filasAfectadas = statement.executeUpdate();

            // Confirmar la transacción
            connection.commit();

            // Devolver true si se insertaron correctamente todas las filas
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }


    public void vergrupos(ActionEvent event) {
        // Limpiar el contenido actual del TextArea
        vergrupos_bucar.clear();

        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la sentencia SQL para seleccionar todos los nombres de los grupos
            String sql = "SELECT NombreGrupo,nombreDenominacion FROM Grupo";
            PreparedStatement statement = connection.prepareStatement(sql);

            // Ejecutar la consulta SQL
            ResultSet resultSet = statement.executeQuery();

            // Recorrer los resultados y agregar los nombres de los grupos al TextArea
            while (resultSet.next()) {
                String nombreGrupo = resultSet.getString("NombreGrupo");
                String denominacionGrupo= resultSet.getString("nombreDenominacion");
                vergrupos_bucar.appendText(nombreGrupo + " (" + denominacionGrupo + ")\n ");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar cualquier error de base de datos aquí
            mostrarAlerta("Error", "Hubo un problema al obtener los nombres de los grupos.");
        }
    }
        public void historialgrupos(ActionEvent event) {
        // Implementar lógica para ver los grupos
        String nombreGrupo = nombre_bucar.getText();

        // Aquí iría la lógica para buscar los grupos en la base de datos o realizar otras operaciones

        // Por ahora, simplemente mostraremos el nombre del grupo en el TextArea
        vergrupos_bucar.setText("Grupo encontrado: " + nombreGrupo);
    }

    public void buscargrupo(ActionEvent event) {
        // Limpiar el contenido actual del TextArea
        verpesonas_buscar.clear();

        // Obtener el nombre del grupo ingresado por el usuario
        String nombreGrupo = nombre_bucar.getText();
        String nombreDenominacion = nombre_bucar.getText();
        if (campoVacio(nombreGrupo)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarCampos(nombreGrupo)) {
            mostrarAlerta("Error", "Los campos deben contener solo letras y tildes.");
            return;
        }
        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la consulta SQL para buscar el grupo en la tabla Grupo
            String sqlGrupo = "SELECT NombreGrupo, nombreDenominacion,nombreJefe FROM Grupo WHERE NombreGrupo  LIKE ? OR nombreDenominacion  LIKE ?";
            PreparedStatement statementGrupo = connection.prepareStatement(sqlGrupo);
            statementGrupo.setString(1,"%"+ nombreGrupo+"%");
            statementGrupo.setString(2, "%"+nombreDenominacion+"%");

            // Ejecutar la consulta SQL para obtener la información del grupo
            ResultSet resultSetGrupo = statementGrupo.executeQuery();

            if (resultSetGrupo.next()) {
                // Se encontró el grupo, obtener su nombre y el nombre del jefe
                String nombreDelGrupo = resultSetGrupo.getString("NombreGrupo");
                String denominacionGrupo = resultSetGrupo.getString("nombreDenominacion");
                String nombreDelJefe = resultSetGrupo.getString("nombreJefe");

                // Mostrar la información del grupo en el TextArea
                verpesonas_buscar.appendText("Grupo encontrado: " + nombreDelGrupo + "\n");
                verpesonas_buscar.appendText("Acrónimo del grupo encontrado: " + denominacionGrupo + "\n");
                verpesonas_buscar.appendText("Nombre del jefe de grupo: " + nombreDelJefe + "\n");

                // Preparar la consulta SQL para buscar los integrantes del grupo en la tabla DatosPersonales
                String sqlIntegrantes = "SELECT nombre, apellidos FROM DatosPersonales WHERE grupo = ?";
                PreparedStatement statementIntegrantes = connection.prepareStatement(sqlIntegrantes);
                statementIntegrantes.setString(1, nombreGrupo);

                // Ejecutar la consulta SQL para obtener los integrantes del grupo
                ResultSet resultSetIntegrantes = statementIntegrantes.executeQuery();

                // Mostrar los nombres y apellidos de los integrantes en el TextArea
                verpesonas_buscar.appendText("Participantes:\n");
                while (resultSetIntegrantes.next()) {
                    String nombre = resultSetIntegrantes.getString("nombre");
                    String apellidos = resultSetIntegrantes.getString("apellidos");
                    verpesonas_buscar.appendText(nombre + " " + apellidos + "\n");
                }
            } else {
                // No se encontró el grupo, mostrar un mensaje indicando que no se encontró el grupo
                verpesonas_buscar.setText("No se encontró el grupo con el nombre proporcionado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar cualquier error de base de datos aquí
            mostrarAlerta("Error", "Hubo un problema al buscar el grupo.");
        }
    }
    public void verTodosLosGrupos(ActionEvent event) {
        // Limpiar el contenido actual del TextArea
        verpesonas_buscar.clear();

        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la consulta SQL para obtener todos los grupos
            String sqlGrupos = "SELECT NombreGrupo, nombreDenominacion,nombreJefe FROM Grupo";
            PreparedStatement statementGrupos = connection.prepareStatement(sqlGrupos);

            // Ejecutar la consulta SQL para obtener todos los grupos
            ResultSet resultSetGrupos = statementGrupos.executeQuery();

            // Iterar sobre los resultados de la consulta para cada grupo
            while (resultSetGrupos.next()) {
                // Obtener el nombre del grupo y el nombre del jefe
                String nombreGrupo = resultSetGrupos.getString("NombreGrupo");
                String nombreDenominacion = resultSetGrupos.getString("nombreDenominacion");
                String nombreJefe = resultSetGrupos.getString("nombreJefe");

                // Mostrar el nombre del grupo y el nombre del jefe en el TextArea
                verpesonas_buscar.appendText("Grupo: " + nombreGrupo + "\n");
                verpesonas_buscar.appendText("Jefe: " + nombreJefe + "\n");

                // Preparar la consulta SQL para obtener los participantes del grupo
                String sqlIntegrantes = "SELECT nombre, apellidos FROM DatosPersonales WHERE grupo = ?";
                PreparedStatement statementIntegrantes = connection.prepareStatement(sqlIntegrantes);
                statementIntegrantes.setString(1, nombreGrupo);

                // Ejecutar la consulta SQL para obtener los participantes del grupo
                ResultSet resultSetIntegrantes = statementIntegrantes.executeQuery();

                // Mostrar los nombres y apellidos de los participantes en el TextArea
                verpesonas_buscar.appendText("Participantes:\n");
                while (resultSetIntegrantes.next()) {
                    String nombre = resultSetIntegrantes.getString("nombre");
                    String apellidos = resultSetIntegrantes.getString("apellidos");
                    verpesonas_buscar.appendText(nombre + " " + apellidos + "\n");
                }
                // Separar grupos con guiones
                verpesonas_buscar.appendText("-----------------------------------------\n");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Manejar cualquier error de base de datos aquí
            mostrarAlerta("Error", "Hubo un problema al buscar los grupos.");
        }
    }


    public void borargrupo(ActionEvent event) {
            // Implementar lógica para borrar un grupo
            String nombreGrupo = nombre_borar.getText();
        if (campoVacio(nombreGrupo)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
            if (!validarCampos(nombreGrupo)) {
            mostrarAlerta("Error", "Los campos deben contener solo letras y tildes.");
            return;
            }
            // Por ahora, simplemente eliminaremos el grupo con el nombre proporcionado
            boolean eliminacionExitosa = eliminarGrupoPorNombre(nombreGrupo);

            // Verificar si la eliminación fue exitosa
            if (eliminacionExitosa) {
                mostrarAlerta("Éxito", "Grupo '" + nombreGrupo + "' eliminado exitosamente.");
            } else {
                mostrarAlerta("Error", "No se pudo eliminar el grupo '" + nombreGrupo + "'.");
            }
        }

    // Método para eliminar un grupo por su nombre
    private boolean eliminarGrupoPorNombre(String nombreGrupo) {
        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la sentencia SQL para eliminar el grupo por su nombre
            String sql = "DELETE FROM Grupo WHERE NombreGrupo = ? OR NombreDenominacion = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nombreGrupo);
            statement.setString(2, nombreGrupo);
            // Ejecutar la sentencia SQL para eliminar el grupo
            int filasAfectadas = statement.executeUpdate();

            // Confirmar la transacción
            connection.commit();

            // Devolver true si se eliminó correctamente al menos una fila
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    public void EntarGrupos(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmGrupo.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmGrupo.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void EntrarPersonal(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarPersonalActualizar(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonalActualizar.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarListado(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de Listado.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Listado.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirAyuda(ActionEvent event) {
        // Obtener la URL del archivo de ayuda
        URL urlArchivoAyuda = getClass().getResource("/com/example/iubo/CHM/AyudaIUBO.chm");

        // Verificar si la URL no es nula
        if (urlArchivoAyuda != null) {
            try {
                // Abrir el archivo de ayuda en el programa predeterminado asociado con los archivos .chm
                Desktop.getDesktop().open(new File(urlArchivoAyuda.toURI()));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("No se pudo encontrar el archivo de ayuda.");
        }
    }

    public void cerrarSesion(ActionEvent event) {
        try {
            // Obtener el escenario actual desde el evento
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Lógica para cerrar sesión, como limpiar datos de usuario, restablecer estado, etc.

            // Cargar el FXML del menú de inicio de sesión
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
