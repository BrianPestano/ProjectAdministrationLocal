package com.example.iubo;

import java.time.LocalDate;

public class Usuario {
    private String nombre;
    private String apellido;
    private String dni;
    private String correoElectronico;
    private String pais;
    private LocalDate fechaNacimiento;
    private String institucionOrigen;
    private LocalDate fechaAlta;
    private LocalDate fechaBaja;
    private boolean esDoctor;
    private String grupo;
    private String motivo;

    // Constructor
    public Usuario(String nombre, String apellido, String dni, String correoElectronico,
                   String pais, LocalDate fechaNacimiento, String institucionOrigen,
                   LocalDate fechaAlta, LocalDate fechaBaja, boolean esDoctor,
                   String grupo, String motivo) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.dni = dni;
        this.correoElectronico = correoElectronico;
        this.pais = pais;
        this.fechaNacimiento = fechaNacimiento;
        this.institucionOrigen = institucionOrigen;
        this.fechaAlta = fechaAlta;
        this.fechaBaja = fechaBaja;
        this.esDoctor = esDoctor;
        this.grupo = grupo;
        this.motivo = motivo;
    }

    // Getters y setters

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public String getPais() {
        return pais;
    }

    public void setPais(String pais) {
        this.pais = pais;
    }

    public LocalDate getFechaNacimiento() {
        return fechaNacimiento;
    }

    public void setFechaNacimiento(LocalDate fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public String getInstitucionOrigen() {
        return institucionOrigen;
    }

    public void setInstitucionOrigen(String institucionOrigen) {
        this.institucionOrigen = institucionOrigen;
    }

    public LocalDate getFechaAlta() {
        return fechaAlta;
    }

    public void setFechaAlta(LocalDate fechaAlta) {
        this.fechaAlta = fechaAlta;
    }

    public LocalDate getFechaBaja() {
        return fechaBaja;
    }

    public void setFechaBaja(LocalDate fechaBaja) {
        this.fechaBaja = fechaBaja;
    }

    public boolean isEsDoctor() {
        return esDoctor;
    }

    public void setEsDoctor(boolean esDoctor) {
        this.esDoctor = esDoctor;
    }

    public String getGrupo() {
        return grupo;
    }

    public void setGrupo(String grupo) {
        this.grupo = grupo;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }
}
