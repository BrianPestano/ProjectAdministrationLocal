package com.example.iubo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLConnection {

    private static final String USER_DB = "root";
    private static final String PASSWORD_DB = ""; // La contraseña debería estar protegida
    private static final String URL = "jdbc:mysql://localhost:3306/iubo-project"; // URL completa con el nombre de la base de datos

    public static Connection connectDB() {
        Connection mySQLConnection = null;
        try {
            mySQLConnection = DriverManager.getConnection(URL, USER_DB, PASSWORD_DB);
            mySQLConnection.setAutoCommit(false);
            System.out.println("[i] Conexión exitosa.");
        } catch (SQLException e) {
            System.out.println("[!] No se ha podido establecer conexión con la base de datos");
            e.printStackTrace();
        }
        return mySQLConnection;
    }

    public void crearTablas(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            // Crear tabla Administracion si no existe
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Administracion ("
                    + "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
                    + "nombre_usuario VARCHAR(255), "
                    + "contrasena VARCHAR(255)"
                    + ")");

            // Crear tabla Historial si no existe
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Historial ("
                    + "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
                    + "descripcion VARCHAR(255), "
                    + "motivo VARCHAR(255)"
                    + ")");

            // Crear tabla DatosPersonales si no existe
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS DatosPersonales ("
                    + "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
                    + "DNI CHAR(9), "
                    + "nombre VARCHAR(255), "
                    + "apellidos VARCHAR(255), "
                    + "Gmail VARCHAR(255), "
                    + "Pais VARCHAR(255), "
                    + "fecha_nacimiento VARCHAR(255), "
                    + "institucion_origen VARCHAR(255), "
                    + "fecha_alta VARCHAR(255), "
                    + "fecha_baja VARCHAR(255), "
                    + "doctor VARCHAR(255), "
                    + "grupo VARCHAR(255), "
                    + "motivo VARCHAR(255)"
                    + ")");

            // Crear tabla Grupo si no existe
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS Grupo ("
                    + "id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,"
                    + "NombreGrupo VARCHAR(255), "
                    + "NombreDenominacion VARCHAR(255), "
                    + "nombreJefe VARCHAR(255), "
                    + "ApellidoJefe VARCHAR(255), "
                    + "fechaCreacion VARCHAR(255)"
                    + ")");

            System.out.println("Tablas creadas exitosamente.");
        } catch (SQLException ex) {
            System.err.println("Error al crear las tablas.");
            ex.printStackTrace();
        }
    }

    public boolean tablasExisten(Connection connection) {
        try (Statement statement = connection.createStatement()) {
            // Verificar si existen las tablas Administracion, Historial y DatosPersonales
            boolean adminTableExists = statement.executeQuery("SHOW TABLES LIKE 'Administracion'").next();
            boolean historyTableExists = statement.executeQuery("SHOW TABLES LIKE 'Historial'").next();
            boolean personalDataTableExists = statement.executeQuery("SHOW TABLES LIKE 'DatosPersonales'").next();

            return adminTableExists && historyTableExists && personalDataTableExists;
        } catch (SQLException ex) {
            System.err.println("Error al verificar la existencia de las tablas.");
            ex.printStackTrace();
            return false;
        }
    }
}
