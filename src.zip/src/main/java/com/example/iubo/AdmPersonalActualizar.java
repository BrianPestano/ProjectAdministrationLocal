package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdmPersonalActualizar {

    @FXML
    private TextField nombreField;

    @FXML
    private TextField dniField;

    @FXML
    private TextField dniBuscarPersona;

    @FXML
    private TextField apellidoField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField fechaBajaField;

    @FXML
    private TextField fechaAltaField;

    @FXML
    private TextField paisField;

    @FXML
    private TextField institucionOrigenField;

    @FXML
    private TextField fechaNacimientoField;

    @FXML
    private ComboBox<String> motivoComboBox;

    @FXML
    private ComboBox<String> sinoComboBox;

    @FXML
    private TextField gruposField;
    public void EntarGrupos(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmGrupo.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmGrupo.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void EntrarPersonal(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarPersonalActualizar(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonalActualizar.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarListado(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Cargar el FXML de Listado.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Listado.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    public void comprobarDNI(ActionEvent event) {
        // Obtener el DNI a buscar
        String dniBuscar = dniBuscarPersona.getText();
        if (campoVacio(dniBuscar)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarFormatoDocumento(dniBuscar)) {
            mostrarAlerta("Error", "El formato del dni debe ser 8 numero y una letra");
            return;
        }
        try (Connection connection = MySQLConnection.connectDB()) {
            String sql = "SELECT * FROM datospersonales WHERE dni = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, dniBuscar);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                // Se encontraron resultados, establecer todos los campos
                dniField.setText(resultSet.getString("dni"));
                nombreField.setText(resultSet.getString("nombre"));
                apellidoField.setText(resultSet.getString("apellidos"));
                emailField.setText(resultSet.getString("Gmail"));
                fechaBajaField.setText(resultSet.getString("fecha_baja"));
                fechaAltaField.setText(resultSet.getString("fecha_alta"));
                paisField.setText(resultSet.getString("Pais"));
                institucionOrigenField.setText(resultSet.getString("institucion_origen"));
                fechaNacimientoField.setText(resultSet.getString("fecha_nacimiento"));
                motivoComboBox.setValue(resultSet.getString("motivo"));
                sinoComboBox.setValue(resultSet.getString("doctor"));
                gruposField.setText(resultSet.getString("grupo"));

                // Mostrar mensaje de éxito
                mostrarAlerta("Éxito", "Se han cargado los datos para el DNI proporcionado.");
            } else {
                // No se encontraron resultados, limpiar todos los campos
                limpiarCampos();

                // Mostrar mensaje de error
                mostrarAlerta("Error", "El DNI proporcionado no existe en la base de datos.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            // Mostrar mensaje de error en caso de excepción
            mostrarAlerta("Error", "Hubo un problema al realizar la verificación del DNI en la base de datos.");
        }
    }
    private boolean campoVacio(String... campos) {
        for (String campo : campos) {
            if (campo == null || campo.trim().isEmpty()) {
                return true; // Si encuentra un campo vacío, devuelve true
            }
        }
        return false; // Si ninguno de los campos está vacío, devuelve false
    }

    // Método para limpiar todos los campos
    @FXML
    private void limpiarCampos() {
        nombreField.clear();
        dniField.clear();
        dniBuscarPersona.clear();
        apellidoField.clear();
        emailField.clear();
        fechaBajaField.clear();
        fechaAltaField.clear();
        paisField.clear();
        institucionOrigenField.clear();
        fechaNacimientoField.clear();
        motivoComboBox.getSelectionModel().clearSelection();
        sinoComboBox.getSelectionModel().clearSelection();
        gruposField.clear();
    }
    @FXML
    private void alta() {
        // Obtener los nuevos valores de los campos
        String nuevoDNI = dniField.getText();
        String nuevoNombre = nombreField.getText();
        String nuevoApellido = apellidoField.getText();
        String nuevoEmail = emailField.getText();
        String nuevaFechaBaja = fechaBajaField.getText();
        String nuevaFechaAlta = fechaAltaField.getText();
        String nuevoPais = paisField.getText();
        String nuevaInstitucionOrigen = institucionOrigenField.getText();
        String nuevaFechaNacimiento = fechaNacimientoField.getText();
        String nuevoMotivo = motivoComboBox.getValue();
        String nuevoDoctor = sinoComboBox.getValue();
        String nuevoGrupo = gruposField.getText();

        // Validar los campos
        if (campoVacio(nuevoNombre, nuevoDNI, nuevoApellido, nuevoEmail, nuevoPais, nuevaInstitucionOrigen, nuevaFechaNacimiento, nuevoGrupo)) {
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarFormatoDocumento(nuevoDNI)) {
            mostrarAlerta("Error", "El formato del DNI debe ser 8 números y una letra.");
            return;
        }
        if (!validarCampos(nuevoNombre, nuevoApellido, nuevoPais, nuevaInstitucionOrigen, nuevoGrupo)) {
            mostrarAlerta("Error", "Los campos deben contener solo letras y tildes.");
            return;
        }
        if (!validarFormatoFecha(nuevaFechaBaja, nuevaFechaAlta, nuevaFechaNacimiento)) {
            mostrarAlerta("Error", "El formato de la fecha debe ser dd/mm/aaaa.");
            return;
        }
        if (!validarFormatoEmail(nuevoEmail)) {
            mostrarAlerta("Error", "El formato del correo electrónico es incorrecto.");
            return;
        }

        try (Connection connection = MySQLConnection.connectDB()) {
            // Crear la consulta SQL para insertar los datos de la nueva persona
            String sql = "INSERT INTO datospersonales (dni, nombre, apellidos, Gmail, fecha_baja, fecha_alta, Pais, institucion_origen, fecha_nacimiento, motivo, doctor, grupo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nuevoDNI);
            statement.setString(2, nuevoNombre);
            statement.setString(3, nuevoApellido);
            statement.setString(4, nuevoEmail);
            statement.setString(5, nuevaFechaBaja);
            statement.setString(6, nuevaFechaAlta);
            statement.setString(7, nuevoPais);
            statement.setString(8, nuevaInstitucionOrigen);
            statement.setString(9, nuevaFechaNacimiento);
            statement.setString(10, nuevoMotivo);
            statement.setString(11, nuevoDoctor);
            statement.setString(12, nuevoGrupo);

            // Ejecutar la inserción
            int rowsInserted = statement.executeUpdate();

            if (rowsInserted > 0) {
                // Confirmar la transacción
                connection.commit();
                mostrarAlerta("Éxito", "La persona se ha creado correctamente.");
                // Limpiar los campos después de la creación
                limpiarCampos();
            } else {
                mostrarAlerta("Error", "No se pudo crear la persona.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al crear la persona.");
        }
    }

    public void actualizarDatos(ActionEvent event) {
        // Obtener el DNI a buscar
        String dni = dniBuscarPersona.getText();

        // Obtener los nuevos valores de los campos
        String nuevoDNI = dniField.getText();
        String nuevoNombre = nombreField.getText();
        String nuevoApellido = apellidoField.getText();
        String nuevoEmail = emailField.getText();
        String nuevaFechaBaja = fechaBajaField.getText();
        String nuevaFechaAlta = fechaAltaField.getText();
        String nuevoPais = paisField.getText();
        String nuevaInstitucionOrigen = institucionOrigenField.getText();
        String nuevaFechaNacimiento = fechaNacimientoField.getText();
        String nuevoMotivo = motivoComboBox.getValue();
        String nuevoDoctor = sinoComboBox.getValue();
        String nuevoGrupo = gruposField.getText();

        // Validar los campos
        if (campoVacio(nuevoNombre, nuevoDNI, nuevoApellido, nuevoEmail, nuevoPais, nuevaInstitucionOrigen, nuevoGrupo)) {
            mostrarAlerta("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarFormatoDocumento(nuevoDNI)) {
            mostrarAlerta("Error", "El formato del DNI debe ser 8 números y una letra.");
            return;
        }
        if (!validarCampos(nuevoNombre, nuevoApellido, nuevoPais, nuevaInstitucionOrigen, nuevoGrupo)) {
            mostrarAlerta("Error", "Los campos deben contener solo letras y tildes.");
            return;
        }
        if (!validarFormatoFecha(nuevaFechaBaja, nuevaFechaAlta, nuevaFechaNacimiento)) {
            mostrarAlerta("Error", "El formato de la fecha debe ser dd/mm/aaaa.");
            return;
        }
        if (!validarFormatoEmail(nuevoEmail)) {
            mostrarAlerta("Error", "El formato del correo electrónico es incorrecto.");
            return;
        }

        try (Connection connection = MySQLConnection.connectDB()) {
            // Crear la consulta SQL para actualizar los datos
            String sql = "UPDATE datospersonales SET dni = ?, nombre = ?, apellidos = ?, Gmail = ?, fecha_baja = ?, fecha_alta = ?, Pais = ?, institucion_origen = ?, fecha_nacimiento = ?, motivo = ?, doctor = ?, grupo = ? WHERE dni = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nuevoDNI);
            statement.setString(2, nuevoNombre);
            statement.setString(3, nuevoApellido);
            statement.setString(4, nuevoEmail);
            statement.setString(5, nuevaFechaBaja);
            statement.setString(6, nuevaFechaAlta);
            statement.setString(7, nuevoPais);
            statement.setString(8, nuevaInstitucionOrigen);
            statement.setString(9, nuevaFechaNacimiento);
            statement.setString(10, nuevoMotivo);
            statement.setString(11, nuevoDoctor);
            statement.setString(12, nuevoGrupo);
            statement.setString(13, dni); // DNI para la condición WHERE

            // Ejecutar la actualización
            int rowsUpdated = statement.executeUpdate();

            if (rowsUpdated > 0) {
                // Confirmar la transacción
                connection.commit();
                mostrarAlerta("Éxito", "Los datos se actualizaron correctamente.");
                // Limpiar los campos después de la actualización
                limpiarCampos();
            } else {
                mostrarAlerta("Error", "No se pudieron actualizar los datos.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al actualizar los datos.");
        }
    }


    private boolean validarFormatoDocumento(String... documentos) {
        String regex = "^((\\d{8}[A-Z])|(\\d{9})|([A-Z]{3}\\d{6}))$";
        for (String documento : documentos) {
            if (!documento.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarFormatoFecha(String... fechas) {
        String regex = "^\\d{2}/\\d{2}/\\d{4}$";
        for (String fecha : fechas) {
            if (!fecha.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarFormatoEmail(String... emails) {
        String regex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        for (String email : emails) {
            if (!email.matches(regex)) {
                return false;
            }
        }
        return true;
    }

    private boolean validarCampos(String... campos) {
        String regex = "^[a-zA-ZñÑáéíóúüÁÉÍÓÚÜ\\s]+$";
        for (String campo : campos) {
            if (!campo.matches(regex)) {
                return false;
            }
        }
        return true;
    }


    // Método para mostrar una alerta
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    public void cerrarSesion(ActionEvent event) {
        try {
            // Obtener el escenario actual desde el evento
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Lógica para cerrar sesión, como limpiar datos de usuario, restablecer estado, etc.

            // Cargar el FXML del menú de inicio de sesión
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirAyuda(ActionEvent event) {
        // Obtener la URL del archivo de ayuda
        URL urlArchivoAyuda = getClass().getResource("/com/example/iubo/CHM/AyudaIUBO.chm");

        // Verificar si la URL no es nula
        if (urlArchivoAyuda != null) {
            try {
                // Abrir el archivo de ayuda en el programa predeterminado asociado con los archivos .chm
                Desktop.getDesktop().open(new File(urlArchivoAyuda.toURI()));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("No se pudo encontrar el archivo de ayuda.");
        }
    }
}