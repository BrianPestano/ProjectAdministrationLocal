package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.FileChooser;

import javax.imageio.ImageIO;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.net.URISyntaxException;
import java.net.URL;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class Listado {

        @FXML
         private String nombreBuscar ="";

        @FXML
         private String apellidosBuscar="";
        @FXML
        private TextField nombre;

        @FXML
        private TextField apellidos;

        @FXML
        private TextArea informacion;

        @FXML
        private Button buscarButton;

        @FXML
        private Button todosButton;

        @FXML
        private Button activosButton;

        @FXML
        private Button noActivosButton;
    @FXML
    private void buscar(KeyEvent event) {
        String nombreBuscar = nombre.getText();
        String apellidosBuscar = apellidos.getText();

        // Conexión a la base de datos
        try (Connection connection = MySQLConnection.connectDB()) {
            String sql;
            PreparedStatement statement = null;

            if (!nombreBuscar.isEmpty() && !apellidosBuscar.isEmpty()) {
                    sql = "SELECT * FROM DatosPersonales WHERE nombre LIKE ? AND apellidos LIKE ? ORDER BY nombre";
                    statement = connection.prepareStatement(sql);
                    statement.setString(1, nombreBuscar.isEmpty() ? "%" : "%"+nombreBuscar + "%");
                    statement.setString(2, apellidosBuscar.isEmpty() ? "%" : "%"+apellidosBuscar + "%");
                } else if (!nombreBuscar.isEmpty()) {
                // Modificar la consulta para buscar nombres que comiencen con la letra ingresada
                sql = "SELECT * FROM DatosPersonales WHERE nombre LIKE ? ORDER BY nombre";
                statement = connection.prepareStatement(sql);
                statement.setString(1, "%"+nombreBuscar + "%");
            } else if(!apellidosBuscar.isEmpty()) {
                // Modificar la consulta para buscar nombres que comiencen con la letra ingresada
                sql = "SELECT * FROM DatosPersonales WHERE apellidos LIKE ? ORDER BY nombre";
                statement = connection.prepareStatement(sql);
                statement.setString(1, "%"+apellidosBuscar + "%");
            }

            ResultSet resultSet = statement.executeQuery();

            StringBuilder resultado = new StringBuilder();
            while (resultSet.next()) {
                resultado.append("Nombre: ").append(resultSet.getString("nombre")).append("\n")
                        .append("Apellidos: ").append(resultSet.getString("apellidos")).append("\n")
                        .append("DNI: ").append(resultSet.getString("DNI")).append("\n")
                        .append("Gmail: ").append(resultSet.getString("Gmail")).append("\n")
                        .append("País: ").append(resultSet.getString("Pais")).append("\n")
                        .append("Fecha de nacimiento: ").append(resultSet.getString("fecha_nacimiento")).append("\n")
                        .append("Institución de origen: ").append(resultSet.getString("institucion_origen")).append("\n")
                        .append("Fecha de alta: ").append(resultSet.getString("fecha_alta")).append("\n")
                        .append("Fecha de baja: ").append(resultSet.getString("fecha_baja")).append("\n")
                        .append("Doctor: ").append(resultSet.getString("doctor")).append("\n")
                        .append("Grupo: ").append(resultSet.getString("grupo")).append("\n")
                        .append("Motivo: ").append(resultSet.getString("motivo")).append("\n")
                        .append("-----------------------------------------\n");
            }

            informacion.setText(resultado.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al buscar las personas.");
        }}
    private boolean campoVacio(String... campos) {
        for (String campo : campos) {
            if (campo == null || campo.trim().isEmpty()) {
                return true; // Si encuentra un campo vacío, devuelve true
            }
        }
        return false; // Si ninguno de los campos está vacío, devuelve false
    }
    private boolean validarCampos(String... campos) {
        String regex = "^[a-zA-ZáéíóúüÁÉÍÓÚÜ\\s]+$";
        for (String campo : campos) {
            if (!campo.matches(regex)) {
                return false;
            }
        }
        return true;
    }

    // Método para mostrar todos los datos personales
    @FXML
    private void todos(ActionEvent event) {
        try (Connection connection = MySQLConnection.connectDB()) {
            String sql = "SELECT * FROM DatosPersonales ORDER BY nombre, apellidos";
            PreparedStatement statement = connection.prepareStatement(sql);
            ResultSet resultSet = statement.executeQuery();

            StringBuilder resultado = new StringBuilder();
            while (resultSet.next()) {
                resultado.append("Nombre: ").append(resultSet.getString("nombre")).append("\n")
                        .append("Apellidos: ").append(resultSet.getString("apellidos")).append("\n")
                        .append("DNI: ").append(resultSet.getString("DNI")).append("\n")
                        .append("Gmail: ").append(resultSet.getString("Gmail")).append("\n")
                        .append("País: ").append(resultSet.getString("Pais")).append("\n")
                        .append("Fecha de nacimiento: ").append(resultSet.getString("fecha_nacimiento")).append("\n")
                        .append("Institución de origen: ").append(resultSet.getString("institucion_origen")).append("\n")
                        .append("Fecha de alta: ").append(resultSet.getString("fecha_alta")).append("\n")
                        .append("Fecha de baja: ").append(resultSet.getString("fecha_baja")).append("\n")
                        .append("Doctor: ").append(resultSet.getString("doctor")).append("\n")
                        .append("Grupo: ").append(resultSet.getString("grupo")).append("\n")
                        .append("Motivo: ").append(resultSet.getString("motivo")).append("\n")
                        .append("-----------------------------------------\n");
            }

            informacion.setText(resultado.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al mostrar todos los datos.");
        }
    }

    // Método para filtrar personas activas
    @FXML
    private void activos(ActionEvent event) {
        try (Connection connection = MySQLConnection.connectDB()) {
            // Obtener la fecha actual
            LocalDate fechaActual = LocalDate.now();

            // Formatear la fecha actual con el formato dd-MM-yyyy
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String fechaActualFormateada = fechaActual.format(formatter);

            String sql = "SELECT * FROM DatosPersonales WHERE fecha_baja >= ? ORDER BY nombre";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, fechaActualFormateada);

            ResultSet resultSet = statement.executeQuery();

            StringBuilder resultado = new StringBuilder();
            while (resultSet.next()) {
                resultado.append("Nombre: ").append(resultSet.getString("nombre")).append("\n")
                        .append("Apellidos: ").append(resultSet.getString("apellidos")).append("\n")
                        .append("DNI: ").append(resultSet.getString("DNI")).append("\n")
                        .append("Gmail: ").append(resultSet.getString("Gmail")).append("\n")
                        .append("País: ").append(resultSet.getString("Pais")).append("\n")
                        .append("Fecha de nacimiento: ").append(resultSet.getString("fecha_nacimiento")).append("\n")
                        .append("Institución de origen: ").append(resultSet.getString("institucion_origen")).append("\n")
                        .append("Fecha de alta: ").append(resultSet.getString("fecha_alta")).append("\n")
                        .append("Fecha de baja: ").append(resultSet.getString("fecha_baja")).append("\n")
                        .append("Doctor: ").append(resultSet.getString("doctor")).append("\n")
                        .append("Grupo: ").append(resultSet.getString("grupo")).append("\n")
                        .append("Motivo: ").append(resultSet.getString("motivo")).append("\n")
                        .append("-----------------------------------------\n");
            }

            informacion.setText(resultado.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al filtrar personas activas.");
        }
    }


    @FXML
    private void imprimirES(ActionEvent event) {
        // Obtener el contenido del TextArea
        String contenido = informacion.getText();

        // Dividir el contenido en líneas
        String[] lineas = contenido.split("\n");

        // Variables para almacenar el nombre y el apellido
        String nombre = "";
        String apellido = "";

        // Buscar el nombre y el apellido en las líneas
        for (String linea : lineas) {
            if (linea.contains("Nombre:")) {
                // Extraer el nombre de la línea
                nombre = linea.substring(linea.indexOf(":") + 2).trim();
            } else if (linea.contains("Apellidos:")) {
                // Extraer el apellido de la línea
                apellido = linea.substring(linea.indexOf(":") + 2).trim();
            }
        }
        String nombreApellido = "D. David Díaz Díaz, CATEDRÁTICO DE UNIVERSIDAD Y SECRETARIO DEL INSTITUTO UNIVERSITARIO DE BIO-ORGÁNICA ANTONIO GONZÁLEZ \n";
        // Usar el nombre y el apellido para construir el cuerpo del documento
        String cuerpo = "CERTIFICA\n\nQue según consta en el archivo de este instituto, " + nombre + " " + apellido + "\"\n\nY para que conste y surta a los efectos oportunos, se expide la presente certificación a petición de la persona interesada.\n\nEn San Cristóbal de La Laguna, en la fecha indicada al pie.\n\nDavid Díaz Díaz\nSecretario";
        // Crear un nombre único para el archivo Word
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String nombreArchivo = "Documento_" + LocalDateTime.now().format(formatter) + ".docx";

        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialFileName(nombreArchivo);
        File archivo = fileChooser.showSaveDialog(new Stage());

        if (archivo != null) {
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(archivo);

                // Agregar cuerpo del documento
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream));
                writer.write(nombreApellido);
                writer.newLine();
                writer.write(cuerpo);
                writer.newLine();

                // Agregar pie de página
                writer.write("Avda. Astrofísico Francisco Sánchez 2\n38206 La Laguna\nSanta Cruz de Tenerife. Islas Canarias\nT: 922 318 570\null.es");

                writer.close();

                // Mostrar mensaje de éxito
                mostrarAlerta("Éxito", "Documento Word creado y guardado con éxito.");

            } catch (IOException e) {
                e.printStackTrace();
                // Manejar cualquier error de escritura del Word aquí
                mostrarAlerta("Error", "Hubo un problema al guardar el documento Word.");
            }
        }
    }

    @FXML
    private void imprimirEN(ActionEvent event) {
        // Obtener el contenido del TextArea
        String contenido = informacion.getText();

        // Dividir el contenido en líneas
        String[] lineas = contenido.split("\n");

        // Variables para almacenar el nombre y el apellido
        String nombre = "";
        String apellido = "";

        // Buscar el nombre y el apellido en las líneas
        for (String linea : lineas) {
            if (linea.contains("Nombre:")) {
                // Extraer el nombre de la línea
                nombre = linea.substring(linea.indexOf(":") + 2).trim();
            } else if (linea.contains("Apellidos:")) {
                // Extraer el apellido de la línea
                apellido = linea.substring(linea.indexOf(":") + 2).trim();
            }
        }
        String nombreApellido = "Dr. DAVID DIAZ DIAZ, FULL PROFESSOR AND SECRETARY OF INSTITUTO\n" +
                "UNIVERSITARIO DE BIO-ORGÁNICA ANTONIO GONZÁLEZ";
        // Usar el nombre y el apellido para construir el cuerpo del documento
        String cuerpo = "CERTIFIES\n\nThat according to the records of this institute, Mr./Mrs. " + nombre + " " + apellido + "\n\nTEXT THAT CORRESPONDS\nThis certification is issued at the request of the person concerned.\nLa Laguna, on the date indicated below.\n\nDavid Díaz Díaz\nSecretary";
        // Crear un nombre único para el archivo Word
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String nombreArchivo = "Documento_" + LocalDateTime.now().format(formatter) + ".docx";

        FileChooser fileChooser = new FileChooser();
        fileChooser.setInitialFileName(nombreArchivo);
        File archivo = fileChooser.showSaveDialog(new Stage());

        if (archivo != null) {
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(archivo);

                // Agregar cuerpo del documento
                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(fileOutputStream));
                writer.write(nombreApellido);
                writer.newLine();
                writer.write(cuerpo);
                writer.newLine();

                // Agregar pie de página
                writer.write("Avda. Astrofísico Francisco Sánchez 2\n38206 La Laguna\nSanta Cruz de Tenerife. Islas Canarias\nT: 922 318 570\null.es");

                writer.close();

                // Mostrar mensaje de éxito
                mostrarAlerta("Éxito", "Documento Word creado y guardado con éxito.");

            } catch (IOException e) {
                e.printStackTrace();
                // Manejar cualquier error de escritura del Word aquí
                mostrarAlerta("Error", "Hubo un problema al guardar el documento Word.");
            }
        }
    }

    private void mostrarAlertadocumento(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }


    // Método para filtrar personas no activas
    @FXML
    private void noActivos(ActionEvent event) {
        try (Connection connection = MySQLConnection.connectDB()) {
            // Obtener la fecha actual
            LocalDate fechaActual = LocalDate.now();

            // Formatear la fecha actual
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            String fechaActualFormateada = fechaActual.format(formatter);

            String sql = "SELECT * FROM DatosPersonales WHERE fecha_baja < ? ORDER BY nombre";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, fechaActualFormateada);

            ResultSet resultSet = statement.executeQuery();

            StringBuilder resultado = new StringBuilder();
            while (resultSet.next()) {
                resultado.append("Nombre: ").append(resultSet.getString("nombre")).append("\n")
                        .append("Apellidos: ").append(resultSet.getString("apellidos")).append("\n")
                        .append("DNI: ").append(resultSet.getString("DNI")).append("\n")
                        .append("Gmail: ").append(resultSet.getString("Gmail")).append("\n")
                        .append("País: ").append(resultSet.getString("Pais")).append("\n")
                        .append("Fecha de nacimiento: ").append(resultSet.getString("fecha_nacimiento")).append("\n")
                        .append("Institución de origen: ").append(resultSet.getString("institucion_origen")).append("\n")
                        .append("Fecha de alta: ").append(resultSet.getString("fecha_alta")).append("\n")
                        .append("Fecha de baja: ").append(resultSet.getString("fecha_baja")).append("\n")
                        .append("Doctor: ").append(resultSet.getString("doctor")).append("\n")
                        .append("Grupo: ").append(resultSet.getString("grupo")).append("\n")
                        .append("Motivo: ").append(resultSet.getString("motivo")).append("\n")
                        .append("-----------------------------------------\n");
            }

            informacion.setText(resultado.toString());

        } catch (SQLException e) {
            e.printStackTrace();
            mostrarAlerta("Error", "Hubo un problema al filtrar personas no activas.");
        }
    }

    // Método para mostrar una alerta
    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
    public void EntarGrupos(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmGrupo.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmGrupo.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void EntrarPersonal(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmPersonal.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarPersonalActualizar(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonalActualizar.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarListado(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Cargar el FXML de Listado.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Listado.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cerrarSesion(ActionEvent event) {
        try {
            // Obtener el escenario actual desde el evento
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Lógica para cerrar sesión, como limpiar datos de usuario, restablecer estado, etc.

            // Cargar el FXML del menú de inicio de sesión
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirAyuda(ActionEvent event) {
        // Obtener la URL del archivo de ayuda
        URL urlArchivoAyuda = getClass().getResource("/com/example/iubo/CHM/AyudaIUBO.chm");

        // Verificar si la URL no es nula
        if (urlArchivoAyuda != null) {
            try {
                // Abrir el archivo de ayuda en el programa predeterminado asociado con los archivos .chm
                Desktop.getDesktop().open(new File(urlArchivoAyuda.toURI()));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("No se pudo encontrar el archivo de ayuda.");
        }
    }
}
