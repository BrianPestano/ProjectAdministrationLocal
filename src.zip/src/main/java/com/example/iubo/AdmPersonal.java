package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.MenuItem;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;
import java.sql.*;

public class AdmPersonal {

    @FXML
    private TextField nombreField;

    @FXML
    private TextField dniField;

    @FXML
    private TextField dniBuscarPersona;

    @FXML
    private TextField apellidoField;

    @FXML
    private TextField emailField;

    @FXML
    private TextField fechaBajaField;

    @FXML
    private TextField fechaAltaField;

    @FXML
    private TextField paisField;

    @FXML
    private TextField institucionOrigenField;

    @FXML
    private TextField fechaNacimientoField;

    @FXML
    private ComboBox<String> motivoComboBox;

    @FXML
    private ComboBox<String> sinoComboBox;

    @FXML
    private TextField gruposField;

    @FXML
     private TextField dni_borar;

    @FXML
    private TextArea informacionTextArea;

    public void crearPersona(ActionEvent event) {
        // Obtener los datos de los campos de texto
        String nombre = nombreField.getText();
        String apellido = apellidoField.getText();
        String dni = dniField.getText();
        String email = emailField.getText();
        String fechaBaja = fechaBajaField.getText();
        String fechaAlta = fechaAltaField.getText();
        String pais = paisField.getText();
        String institucionOrigen = institucionOrigenField.getText();
        String fechaNacimiento = fechaNacimientoField.getText();
        String motivo = motivoComboBox.getValue();
        String doctor = sinoComboBox.getValue();
        String grupo = gruposField.getText();

        // Verificar si algún campo está vacío
        if (campoVacio(nombre, apellido, dni, email, fechaBaja, fechaAlta, pais, institucionOrigen, fechaNacimiento, motivo, doctor, grupo)) {
            mostrarMensaje("Error", "No se pueden dejar campos vacíos.");
            return;
        }

        // Validar los campos
        if (!validarCampos(nombre, apellido, pais, institucionOrigen, grupo)) {
            mostrarMensaje("Error", "Los campos deben contener solo letras y tildes.");
            return;
        }

        // Validar el formato de las fechas, el email y el documento
        if (!validarFormatoFecha(fechaBaja, fechaAlta, fechaNacimiento)) {
            mostrarMensaje("Error", "El formato de la fecha debe ser dd/dd/dddd.");
            return;
        }
        if (!validarFormatoEmail(email)) {
            mostrarMensaje("Error", "El formato Gmail debe contener una @.");
            return;
        }
        if (!validarFormatoDocumento(dni)) {
            mostrarMensaje("Error", "El formato del DNI debe ser 8 números y una letra.");
            return;
        }

        // Verificar si el grupo existe en la tabla grupos
        if (!existeGrupo(grupo)) {
            mostrarMensaje("Error", "El grupo especificado no existe.");
            return;
        }

        // Conectar a la base de datos y crear la persona
        try (Connection connection = MySQLConnection.connectDB()) {

            String sql = "INSERT INTO datospersonales (DNI, nombre, apellidos, Gmail, Pais, fecha_nacimiento, institucion_origen, fecha_alta, fecha_baja, doctor, grupo, motivo) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, dni);
            statement.setString(2, nombre);
            statement.setString(3, apellido);
            statement.setString(4, email);
            statement.setString(5, pais);
            statement.setString(6, fechaNacimiento);
            statement.setString(7, institucionOrigen);
            statement.setString(8, fechaAlta);
            statement.setString(9, fechaBaja);
            statement.setString(10, doctor);
            statement.setString(11, grupo);
            statement.setString(12, motivo);

            int rowsInserted = statement.executeUpdate();
            // Confirmar la transacción
            connection.commit();
            if (rowsInserted > 0) {
                mostrarMensaje("Éxito", "Persona creada correctamente.");
                limpiarCampos();
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean existeGrupo(String nombreGrupo) {

        try (Connection connection = MySQLConnection.connectDB()) {

            String sql = "SELECT COUNT(*) AS count FROM Grupo WHERE NombreGrupo = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, nombreGrupo);
            ResultSet resultSet = statement.executeQuery();

            if (resultSet.next()) {
                int count = resultSet.getInt("count");
                return count > 0;
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
    private boolean campoVacio(String... campos) {
        for (String campo : campos) {
            if (campo == null || campo.trim().isEmpty()) {
                return true; // Si encuentra un campo vacío, devuelve true
            }
        }
        return false; // Si ninguno de los campos está vacío, devuelve false
    }
    private boolean validarFormatoDocumento(String... documentos) {
        String regex = "^((\\d{8}[A-Z])|(\\d{9})|([A-Z]{3}\\d{6}))$";
        for (String documento : documentos) {
            if (!documento.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarFormatoEmail(String... emails) {
        String regex = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";
        for (String email : emails) {
            if (!email.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarCampos(String... campos) {
        String regex = "^[a-zA-ZñÑáéíóúüÁÉÍÓÚÜ\\s]+$";
        for (String campo : campos) {
            if (!campo.matches(regex)) {
                return false;
            }
        }
        return true;
    }
    private boolean validarFormatoFecha(String... fechas) {
        String regex = "^\\d{2}/\\d{2}/\\d{4}$";
        for (String fecha : fechas) {
            if (!fecha.matches(regex)) {
                return false;
            }
        }
        return true;
    }

    private void mostrarMensaje(String titulo, String contenido) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(contenido);
        alert.showAndWait();
    }

    public void borrarPersona(ActionEvent event) {
        // Implementar lógica para borrar un grupo
        String nombrepersona = dni_borar.getText();
        if (campoVacio(nombrepersona)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarMensaje("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarFormatoDocumento(nombrepersona)) {
            mostrarMensaje("Error", "El formato del dni debe ser 8 numero y una letra");
            return;
        }


        // Aquí iría la lógica para buscar y mostrar los grupos en el TextArea
        // Por ahora, simplemente eliminaremos el grupo con el nombre proporcionado
        boolean eliminacionExitosa = eliminarPersonaPorNombre(nombrepersona);

        // Verificar si la eliminación fue exitosa
        if (eliminacionExitosa) {
            mostrarMensaje("Éxito", "Persona " + nombrepersona + " eliminado exitosamente.");
        } else {
            mostrarMensaje("Error", "No se pudo eliminar a " + nombrepersona + " .");
        }
    }
    private boolean eliminarPersonaPorNombre(String dniBorrar) {
        try (Connection connection = MySQLConnection.connectDB()) {
            // Preparar la sentencia SQL para eliminar el grupo por su nombre
            String sql = "DELETE FROM datospersonales WHERE dni = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, dniBorrar);

            // Ejecutar la sentencia SQL para eliminar el grupo
            int filasAfectadas = statement.executeUpdate();

            // Confirmar la transacción
            connection.commit();

            // Devolver true si se eliminó correctamente al menos una fila
            return filasAfectadas > 0;
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void buscarPersona(ActionEvent event) {
        // Obtener el DNI a buscar
        String dniBuscar = dniBuscarPersona.getText();
        if (campoVacio(dniBuscar)) {
            // Al menos uno de los campos está vacío, mostrar una alerta
            mostrarMensaje("Error", "No se pueden dejar campos vacíos.");
            return;
        }
        if (!validarFormatoDocumento(dniBuscar)) {
            mostrarMensaje("Error", "El formato del dni debe ser 8 numero y una letra");
            return;
        }
        try (Connection connection = MySQLConnection.connectDB()) {

            String sql = "SELECT * FROM datospersonales WHERE dni = ?";
            PreparedStatement statement = connection.prepareStatement(sql);
            statement.setString(1, dniBuscar);

            // Ejecutar la consulta
            ResultSet resultSet = statement.executeQuery();



            // Verificar si se encontraron resultados
            if (resultSet.next()) {
                // Se encontraron resultados
                informacionTextArea.clear();
                do {
                    informacionTextArea.appendText("Nombre: " + resultSet.getString("nombre") + "\n");
                    informacionTextArea.appendText("Apellido: " + resultSet.getString("apellidos") + "\n");
                    informacionTextArea.appendText("DNI: " + resultSet.getString("dni") + "\n");
                    informacionTextArea.appendText("Email: " + resultSet.getString("Gmail") + "\n");
                    informacionTextArea.appendText("Fecha de Baja: " + resultSet.getString("fecha_baja") + "\n");
                    informacionTextArea.appendText("Fecha de Alta: " + resultSet.getString("fecha_alta") + "\n");
                    informacionTextArea.appendText("País: " + resultSet.getString("Pais") + "\n");
                    informacionTextArea.appendText("Institución de Origen: " + resultSet.getString("institucion_origen") + "\n");
                    informacionTextArea.appendText("Fecha de Nacimiento: " + resultSet.getString("fecha_nacimiento") + "\n");
                    informacionTextArea.appendText("Doctor: " + resultSet.getString("doctor") + "\n");
                    informacionTextArea.appendText("Motivo: " + resultSet.getString("motivo") + "\n");
                    informacionTextArea.appendText("Grupos: " + resultSet.getString("grupo") + "\n");
                } while (resultSet.next());
            } else {
                // No se encontraron resultados
                informacionTextArea.setText("No se encontró ninguna persona con el DNI especificado.");
            }


        } catch (SQLException e) {
            e.printStackTrace();
            informacionTextArea.setText("No se encontró ninguna persona con el DNI especificado.");
        }
    }

    // Método para limpiar los campos de texto después de la creación
    private void limpiarCampos() {
        nombreField.clear();
        apellidoField.clear();
        dniField.clear();
        emailField.clear();
        fechaBajaField.clear();
        fechaAltaField.clear();
        paisField.clear();
        institucionOrigenField.clear();
        fechaNacimientoField.clear();
        motivoComboBox.getSelectionModel().clearSelection();
        gruposField.clear();
    }
    public void EntarGrupos(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmGrupo.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmGrupo.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void EntrarPersonal(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarPersonalActualizar(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonalActualizar.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarListado(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de Listado.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Listado.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cerrarSesion(ActionEvent event) {
        try {
            // Obtener el escenario actual desde el evento
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Lógica para cerrar sesión, como limpiar datos de usuario, restablecer estado, etc.

            // Cargar el FXML del menú de inicio de sesión
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirAyuda(ActionEvent event) {
        // Obtener la URL del archivo de ayuda
        URL urlArchivoAyuda = getClass().getResource("/com/example/iubo/CHM/AyudaIUBO.chm");

        // Verificar si la URL no es nula
        if (urlArchivoAyuda != null) {
            try {
                // Abrir el archivo de ayuda en el programa predeterminado asociado con los archivos .chm
                Desktop.getDesktop().open(new File(urlArchivoAyuda.toURI()));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("No se pudo encontrar el archivo de ayuda.");
        }
    }
}
