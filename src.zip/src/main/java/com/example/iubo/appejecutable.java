package com.example.iubo;

public class appejecutable {
    public static void main (String[] args){
        HelloApplication.main(args);
    }
}
