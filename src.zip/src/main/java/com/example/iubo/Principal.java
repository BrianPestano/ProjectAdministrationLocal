package com.example.iubo;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URISyntaxException;
import java.net.URL;

public class Principal {

    public void EntarGrupos(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Obtener el escenario actual desde el MenuItem
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Cargar el FXML de AdmGrupo.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmGrupo.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void EntrarPersonal(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonal.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void EntrarPersonalActualizar(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de AdmPersonalActualizar.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("AdmPersonalActualizar.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @FXML
    private void abrirAyuda(ActionEvent event) {
        // Obtener la URL del archivo de ayuda
        URL urlArchivoAyuda = getClass().getResource("/com/example/iubo/CHM/AyudaIUBO.chm");

        // Verificar si la URL no es nula
        if (urlArchivoAyuda != null) {
            try {
                // Abrir el archivo de ayuda en el programa predeterminado asociado con los archivos .chm
                Desktop.getDesktop().open(new File(urlArchivoAyuda.toURI()));
            } catch (IOException | URISyntaxException e) {
                e.printStackTrace();
            }
        } else {
            System.err.println("No se pudo encontrar el archivo de ayuda.");
        }
    }

    public void EntrarListado(ActionEvent event) {
        try {
            // Obtener el MenuItem actual
            MenuItem menuItem = (MenuItem) event.getSource();

            // Obtener la escena actual desde el MenuItem
            Scene scene = menuItem.getParentPopup().getScene();

            // Cargar el FXML de Listado.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("Listado.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Obtener el escenario actual desde la escena
            Stage stage = (Stage) menuItem.getParentPopup().getOwnerWindow();

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void cerrarSesion(ActionEvent event) {
        try {
            // Obtener el escenario actual desde el evento
            Stage stage = (Stage) ((MenuItem) event.getSource()).getParentPopup().getOwnerWindow();

            // Lógica para cerrar sesión, como limpiar datos de usuario, restablecer estado, etc.

            // Cargar el FXML del menú de inicio de sesión
            FXMLLoader loader = new FXMLLoader(getClass().getResource("hello-view.fxml"));
            Parent root = loader.load();

            // Crear la escena
            Scene newScene = new Scene(root);

            // Establecer la nueva escena en el escenario
            stage.setScene(newScene);
            stage.show();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}
